import { createRouter, createWebHistory } from 'vue-router';
import Home from '@/views/index/Home.vue';
import Question from '@/views/index/Question.vue';
import Team from '@/views/index/Team.vue';


const routes = [
  {
    path: '/',
    redirect: '/login'
  },
  
  {
    path: '/index',
    name: 'index',
    component: () => import('../components/layout/Index.vue'),
    children: [
      {
        path: '/home',
        name: 'home',
        component: () => import('../views/index/home.vue'),
        children: []
      },
      {
        path: '/question',
        name: 'question',
        component: () => import('../views/index/question.vue'),
        children: []
      },
      {
        path: '/team',
        name: 'team',
        component: () => import('../views/index/team.vue'),
        children: []
      },
    ]
  },

  {
    path: '/login',
    name: 'login',
    component: () => import('../views/Login/index.vue'),
   
  },


];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;