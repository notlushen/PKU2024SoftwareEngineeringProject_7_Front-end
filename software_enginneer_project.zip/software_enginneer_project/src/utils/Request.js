import axios from 'axios'
import { config } from 'process';
const contentTypeForm="application/x-www-form-urlencoded;charste=UTF-8";
const contentTpyeJson="application/json";
const contentTypeFile="multipart/form-data";


const request = () =>{
    const{url,params,dataType,showLoading}=config;
    dataType=dataType?"form":dataType;
    showLoading=showLoading?true:showLoading;
    
    let contentType=contentTpyeJson;


}

export default request;