<template>
    <div class="post-list">
      <PostItem v-for="post in posts" :key="post.id" :post="post" />
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  import PostItem from '@/components/PostItem.vue';

  const posts = ref([
    { id: 1, title: 'Vue.js 入门教程', content: 'Vue.js 是一个渐进式JavaScript框架...' },
    { id: 2, title: 'React.js 进阶指南', content: 'React.js 是一个用于构建用户界面的JavaScript库...' },
    { id: 3, title: 'Node.js 实战', content: 'Node.js 是一个基于Chrome V8引擎的JavaScript运行环境...' },
  ]);
  </script>
  
  <style scoped>
  .post-list {
    flex: 1;
  }
  
  @media (max-width: 768px) {
    .post-list {
      margin-top: 20px;
    }
  }
  </style>