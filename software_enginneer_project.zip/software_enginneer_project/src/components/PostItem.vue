<template>
    <div class="post-item">
      <div class="post-title">{{ post.title }}</div>
      <div class="post-content">{{ post.content }}</div>
    </div>
  </template>
  
  <script setup>
  defineProps({
    post: Object
  });
  </script>
  
  <style scoped>
  .post-item {
    border: 1px solid #eee;
    margin-bottom: 20px;
    padding: 20px;
    border-radius: 4px;
  }
  
  .post-title {
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 10px;
  }
  
  .post-content {
    color: #666;
  }
  </style>